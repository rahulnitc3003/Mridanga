<!DOCTYPE html>
<head>
<title>New Account</title>
</head>

<body>
<form action="add_account.php" method="post"></br>
<table border="15" align="center" bgcolor="#00CC66" width="387" height="334">
<tr align="center">
	<td colspan="20" bgcolor="#CC6666"><b><i>New account</b></i></td>
</tr>
<tr>
	<td width="148" height="36" align="center">Account Number:</td>
    <td width="195"><input type="text" name="ano" required="*required" placeholder="Enter ano" /></td>
</tr>
<tr>
	<td height="33" align="center">Account type:</td>
    <td><select name="atype">
	<button value="null">account type</button>
	<button value="S">S(saving)</button>
	<button value="C">C(current)</button>
</select></td>
</tr>
<tr>
	<td height="36" align="center">Balance</td>
    <td><input type="text" name="balance" required="*required" placeholder="Enter opening balance" /></td>
</tr>
<tr>
	<td height="36" align="center">Customer Id</td>
    <td><input type="text" name="cid" required="*required" placeholder="Enter Customer id" /></td>
</tr>
<tr>
	<td height="36" align="center">Branch Id</td>
    <td><input type="text" name="bid" required="*required" placeholder="Enter Branch id" /></td>
</tr>
<tr>
	<td height="43" colspan="20" align="center">
    <input type="submit" name="submit" value="Create Account" />
    <input type="reset" name="reset" value="Reset"/>
    <a href="admin_page.php"><input type="button" name="back" value="Back" /></a></td>
</tr>
</table>
</form>
</body>
</html>


<?php
//connection coding
$user = 'root';
$pass = 'nsl';
$db = 'LEPAKSHIBANK';
$db = new mysqli('localhost', $user, $pass, $db) or die("unable to connect");
//echo"connection sucess";
if(isset($_POST['submit']))
{
	$ano = $_POST['ano'];
	$atype = $_POST['atype'];
	$balance = $_POST['balance'];
	$cid = $_POST['cid'];
	$bid = $_POST['bid'];
	$que = "insert into ACCOUNT(ANO,ATYPE,BALANCE,CID,BID)values('$ano','$atype','$balance','$cid','$bid')";
	if(mysqli_query($db,$que))
	{
		echo "<script>alert('Data has been inserted')</script>";
	}
	else
	{
		echo "<script>alert('please cheack foreign key or primary key values')</script>";
	}
}
?>
