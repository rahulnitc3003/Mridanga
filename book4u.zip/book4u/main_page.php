<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Book database management system</title>
</head>

<body background="images/100.jpg">
<br /><br /><br /><br /><br /><br /><br />
<table width="236" height="90" border="10" align="center">
	<tr>
    	<td width="174" height="34" colspan="10" align="center" bgcolor="#CC66FF"><b>GUEST SECTION</b></td>
    </tr>
    <tr>
    	<td align="center"><a href="guest_page.php"><input type="button" name="guest" value="Guest" /></a></td>
    </tr>
</table>

<table width="236" height="90" border="10" align="center">
	<tr>
    	<td width="174" height="34" colspan="10" align="center" bgcolor="#FFFF99"><b>ADMIN SECTION</b></td>
    </tr>
    <tr>
    	<td align="center"><a href="login_form.php"><input type="button" name="admin" value="Admin" /></a></td>
    </tr>
</table>

</body>
</html>