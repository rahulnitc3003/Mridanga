<html>
<head>
<title>books4u database</title>
</head>
<body>
<form action="q1.php" method="post">
	<table width="576" height="74" border="10" align="center" bordercolor="#FF6600" bgcolor="#FFFF99">
    	<tr><br /><br />
        	<td width="759" height="100" align="center">
				<p><i><u>Find book name in inputted category</u></i></p>
            	<b>Enter Book Category</b>
            	<input type="text" name="category" required="*required" />
    			<input type="submit" name="category_find" value="Find book" />
				<a href="guest_page.php"><input type="button" name="back" value="Back" /></a>
    		</td>
        </tr>
</table></br></br>
<center>

<?php
$conn=new mysqli('localhost','root','nsl','book4u') or die('error in database connection');
if(isset($_POST['category_find']))
{
	$category = $_POST['category'];
	$que = "select bookname from book where category='$category'";
	$run = mysqli_query($conn,$que);
	?>
	<table border="10" width="200">
	<tr>
		<td align="center" bgcolor="pink"><b>Serial No.</b></td>
		<td align="center" bgcolor="pink"><b>Book Name</b></td>
	</tr>
	<?php
	$i=1;
	while($row = mysqli_fetch_array($run))
	{
		$bookname = $row['bookname'];
	?>
	
			<tr>
				<td align="center"><?php echo $i;$i++; ?></td>
				<td align="center"><?php echo $bookname; ?></td>
			</tr>
	<?php } ?>
	<?php } ?>
</table>
</center>
</form>
</body>
</html>
