<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" type="image/gif" href="images/icon.jpg" />
<title>Mankind Pharma</title>
<link href="contact_css.css" rel="stylesheet" type="text/css" />
<meta name="viewport" content="width=device-width, intial-scale=1.0" />


</head>
<body>
	<div class="container">
		<header>
		<!--figure class="logo"></figure-->
		<div id="socialicons">
			<a href="https://www.facebook.com/amitstorm/"><img src="images/facebook_icon.jpg" width="37" height="29" /></a>
        	<a href="https://www.mankindpharma.com/"><img src="images/google_icon.jpg" width="37" height="29"	/></a>
			<a href="https://twitter.com/pharma_mankind"><img src="images/twitter_icon.jpg" width="37" height="29"  /></a>
		</div>
		</header>
		<div id="banner">
    		<img src="images/Queen Elizabeth Hospital Birmingham.jpg" width="1000" height="336" />
		</div>
    	<nav class="menubar1">
    		<ul>
    			<li><a href="index.html">Home</a></li>
    			<li><a href="media_kit.html">Overview</a></li>
    			<li><a href="#">Product</a></li>
    			<li><a href="#">Services</a></li>
    			<li><a href="contact.php">Contact us</a></li>
    			<li><a href="admin_login.php">Administrator</a></li>
    		</ul>
    	</nav>
  </div>








