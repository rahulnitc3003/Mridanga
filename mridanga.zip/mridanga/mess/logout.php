<?php
session_start();
session_destroy();
header('location:mess_homepage.php');
?>
<!DOCTYPE HTML>
<html>
<head>
<title>NITC MESS</title>
<link rel="stylesheet" href="../css/abc.css" />
<link rel="icon" type="image/jpg" href="../images/icon.jpg">
</head>
<body>

</body>
</html>